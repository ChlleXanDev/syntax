# ![WebApp]

## Demo
Cooming Soon


## Site

### Syntax - Data
![](./img_readme/userdata.png)

### Syntax - Admin
![](./img_readme/admin.png)

### Syntax - RegisAdmin
![](./img_readme/regisadmin.png)

### Syntax - Registration
![](./img_readme/registrasi.png)

### Syntax - Record
![](./img_readme/success.png)

### Syntax - Verify
![](./img_readme/consolecode.png)

## [License](https://github.com/ChlleXanDev/syntax/blob/main/LICENSE.md)

MIT © [ChlleXanDev](https://github.com/ChlleXanDev)

