<!DOCTYPE html>
<html>
<head>
<link rel="icon" type="image/png" href="../img/syntax.png">
    <script>
        window.onload = function() {
            window.location.href = "login.php";
        }
    </script>
</head>
<body>
</body>
</html>

